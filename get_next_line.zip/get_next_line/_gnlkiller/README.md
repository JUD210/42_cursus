﻿```
git clone https://github.com/DontBreakAlex/gnlkiller.git ; cd gnlkiller; cp ../get_next_line.c .; cp ../get_next_line_utils.c .; cp ../get_next_line.h .; ./run.sh;
```

![Demo](https://s3.gifyu.com/images/gnlkiller64f771561dd24cca.gif)

Tests 42's GNL with different buffer sizes. Forked from [sgah](https://profile.intra.42.fr/users/sgah). C code from [ncolomer](https://profile.intra.42.fr/users/ncolomer).
