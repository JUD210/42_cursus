#include "get_next_line.h"


# include <fcntl.h>
# include <stdio.h>

int		main(void)
{
	int fd1;
	int fd2;

	int rtn;
	char *line;
	// fd1 = open(argv[1], O_RDONLY);
	// fd2 = open(argv[2], O_RDONLY);
	fd1 = open("test1.txt", O_RDONLY);
	fd2 = open("test2.txt", O_RDONLY);

	printf("============================\n");
	while ((rtn = get_next_line(fd1, &line)) == 1)
	{
		printf("[%s]\n", line);
		printf("{%d}\n", rtn);
		printf("---------\n");
		free(line);
	}
	free(line);
	close(fd1);

	printf("============================\n");
	while ((rtn = get_next_line(fd2, &line)) == 1)
	{
		printf("[%s]\n", line);
		printf("{%d}\n", rtn);
		printf("---------\n");
		free(line);
	}
	free(line);
	close(fd2);

	printf("============================\n");
	while ((rtn = get_next_line(0, &line)) == 1)
	{
		printf("[%s]\n", line);
		printf("{%d}\n", rtn);
		printf("---------\n");
		free(line);
	}
	free(line);
}


//@@D TEST /////////////////////
#ifdef TEST2

int		main2(int argc, char *argv[])
{
	printf("argc: %d\n", argc);
	for (int i=0; i<argc; i++)
	{
		// printf("argv[%d]: %s\n", i, argv[i]);
		write(1, argv[i], ft_strlen(argv[i]));
		write(1, &"\n", 1);
	}


	int fd;
	char *line;

	// fd = open("test1.txt", O_RDONLY);
	fd = 0;
	printf("fd:%d\n", fd);
	printf("BUFFER_SIZE:%d\n", BUFFER_SIZE);


	int count = 0;
	int rst;
	while ((rst = get_next_line(fd, &line)) == 1)
	{
		count++;
		printf("================ %d START //[rst]: %d\n", count, rst);
		printf("%s", line);
		printf("~~~~~~~~~~~~~~~~ %d END\n", count);
	}

	return (0);
}




int main3(void)
{
	char	*l;

	if (l == NULL)
		printf("1");

	l = malloc(1000);

	if (*l == '\0')
		printf("2");

	l = "\0 123123123";

	if (l == NULL)
		printf("3");

	if (*l == '\0')
		printf("4");

	return (0);
}
#endif
