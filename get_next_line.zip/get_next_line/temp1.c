/*
123
123
123
123
123
== 123N 123N 123N 123N 123E
//N: newline, E: EOF

// if (saved == null || saved has no newline)
//   read();

[BUFFER_SIZE: 14]
=== 1 ===
saved: null
read: 14
saved: 123N 123N 123N 12
line: 123N

=== 2 === 
saved: 123N 123N 12
line: 123N

=== 3 === 
saved: 123N 12
line: 123N

=== 4 === 
saved: 12
read: 5
saved: 123N 123
line: 123N

=== 5 ===
saved: 123
line: 123

=== 6 ===
saved: null
read: -1
*/
