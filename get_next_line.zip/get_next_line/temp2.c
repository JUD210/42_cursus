/*
==== get_next_line() PSUEDO CODE ====

static char	*saved;
char		*buff;
int			nl_idx;

while ((nl_idx = find_nl(saved)) < 0)
{
	read(fd, buff, BUFFER_SIZE);
	saved += buff
	free(buff);
}

line = saved[0 .. nl_idx]
*/
