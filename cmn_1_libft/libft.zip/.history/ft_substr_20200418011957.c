/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hmin <hmin@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/03/01 00:53:02 by hmin              #+#    #+#             */
/*   Updated: 2020/04/18 01:19:56 by hmin             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(const char *str, unsigned int start, size_t len)
{
	char	*sub_str;
	size_t	start_;
	size_t	i;

	if (!(sub_str = (char *)malloc((len + 1) * sizeof(char))))
		return (NULL);
	if (start >= ft_strlen(str))
		return (NULL);
	start_ = (size_t)start;
	i = 0;
	while (str[start_ + i] && i < len)
	{
		sub_str[i] = str[start_ + i];
		i++;
	}
	sub_str[i] = '\0';
	return (sub_str);
}

#include <stdio.h>

int	main(void)
{
	printf("%s\n", ft_substr("test", 10, 1));

	return (0);
}
